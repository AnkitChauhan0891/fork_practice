<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
$userId = $_SESSION['user_id'];

include 'product.php';

$showProduct = "";

foreach ($product as $key => $val) {
    $availableProduct = "Available In Stock";
    $printPrice;

    if ($val['quantity'] < 1) {
        $availableProduct = "Out Of Stock";
    }

    $discountLabal = "";
    $discountPrice = round(($val['price'] * (100 - $val['discount'])) / 100);
    if ($val['discount'] == 0) {
        $discountLabal = "d-none";
    }

    // rating 
    $printRating = '';
    $rating = $val['rating']['rate'];
    for ($i = 0; $i < 5; $i++) {
        if (($i <= (int)$rating) && (($rating - $i) > 0.75)) {
            $printRating .= '<span class="fa fa-star text-warning"></span>';
        } else if (($i == (int)$rating) && (($rating - (int)$rating) >= 0.25) && (($rating - (int)$rating) <= 0.75)) {
            $printRating .= '<span class="fa fa-star-half-o text-warning"></span>';
        } else {
            $printRating .= '<span class="fa fa-star"></span>';
        }
    }

    //out of stoke
    $valQuantity = 1;
    $outOfStockColorCSS = "";
    $outOfStockPointerEventCSS = "";
    if ($val['quantity'] < 1) {
        $valQuantity = 0;
        $outOfStockColorCSS = "filter: grayscale(100%);";
        $outOfStockPointerEventCSS = "pointer-events:none;";
    }

    //added cart

    $filePath = $_SERVER['DOCUMENT_ROOT'] . '/assets/json/shoppingWebsite.json';
    $getJsonData = file_get_contents($filePath);
    $tempArray = json_decode($getJsonData, true);
    $cartData = array_keys($tempArray[$userId]['cart']);
    $cartQuantity = $tempArray[$userId]['cart'][$key]['quantity'];

    $isCheckedCart = "";

    if (in_array($key, $cartData)) {
        $isCheckedCart = "cartToggle";
        $valQuantity = $cartQuantity;

        $showProduct .= '<div class="col-3 mt-4 text-black product"  style="cursor: pointer;' . $outOfStockColorCSS . '"  id="' . $key . '">
    <div class="card" style="width: 18rem;">
        <div class="position-absolute d-flex flex-row justify-content-between w-100 p-3">
            <div>
                <small class="text-white bg-info p-1 px-2 rounded-2 fw-bold ' . $discountLabal . '">' . $val['discount'] . '% off</small>
                </div>
                <div>
                    <button type="button" class="btn btn-sm btn-primary rounded-circle d-flex justify-content-center">
                        <span class="fa fa-heart text-center rounded-circle" style="font-size: 20px;"></span>
                    </button>
                </div>
            </div>
            <div class="d-flex justify-content-center">
                <img class="card-img-top pt-5" src="' . $val['image'] . '" style="width:180px;height:250px;" alt="Card image cap">
                </div>
                <div style="background-color: rgba(0, 0, 0, 0.08);" class="mt-3">
                    <div class="card-body text-black d-flex justify-content-center flex-column align-items-center">
                        <small class="text-success fw-bold mb-0">( ' . $availableProduct . ' )</small>
                        <h5 class="card-title mt-1 mb-0 text-center" style="font-size: 17px;">' . $val['title'] . '</h5>
                        <p class="text-muted mb-1">' . $val['category'] . '</p>
                        <p class="mb-1"><del class="text-muted fw-bolder me-1">₹' . $val['price'] . '</del>/<span class="ms-1">₹' . $discountPrice . '<span></p>
                        <div class="mb-0">
                        ' . $printRating . '<span class="ms-2">' . $val['rating']['rate'] . '</span>
                        <span class="ms-2">( ' . $val['rating']['count'] . ' )</span>
                        </div>
                    </div style="">
                    <div class="d-flex flex-row justify-content-between mx-3 mb-3 changeCart" style="' . $outOfStockPointerEventCSS . '">
                        <div class="input-group w-100 me-auto">
                            <span class="input-group-btn">
                                <button type="button" class="quantity-left-minus btn btn-sm btn-danger rounded-0 rounded-start shadow-none" data-type="minus" data-field="">
                                    <span class="fa fa-minus"></span>
                                </button>
                            </span>
                            <input type="text" style="height: 31px;width: 34px !important" step="1" id="quantity" name="quantity" class=" border-1 border-start-0 border-end-0 text-center" value="' . $valQuantity . '" min="1" max="' . $val['quantity'] . '">
                            <span class="input-group-btn">
                                <button type="button" class="quantity-right-plus btn btn-sm btn-success btn-number rounded-0 rounded-end shadow-none" data-type="plus" data-field="">
                                    <span class="fa fa-plus"></span>
                                </button>
                            </span>
                        </div>
                        <div class="">
                            <button type="button" class="btn btn-sm btn-primary rounded-circle d-flex justify-content-center addCart removeCart">
                                <span class="fa fa-shopping-cart text-center ' . $isCheckedCart . '" style="font-size: 20px;"></span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>';
    }
}
?>

<?php include '../../header.php'; ?>
<?php include '../sidebar.php'; ?>

<aside aria-label="" class="column_right  php_ajax_shopping" style="overflow-x: hidden !important;">
    <h1 class="path">JavaScript / Module-4 / Assignment / Radix Exam</h1>
    <div class="right_content bg-dark text-white d-flex flex-column justify-content-between">
        <div>
            <div class="d-flex justify-content-between border-bottom border-4 p-2 mb-3  border-white">
                <div class="d-flex flex-row align-items-center">
                    <a href="index.php" class="text-white fw-bold mx-4 text-decoration-none">Home</a>
                    <a href="cart.php" class="text-white fw-bold mx-4 text-decoration-none">Cart</a>
                    <a href="#" class="text-white fw-bold mx-4 text-decoration-none">Order History</a>
                </div>
                <div class="d-flex flex-row flex-shrink-1 ms-auto align-items-center">
                    <a href="logout.php"><i class="fa fa-sign-out fa-2x pe-4 text-danger"></i></a>
                </div>
            </div>
            <div class="overflow-scroll chatApplication ">
                <div class="row">
                    <div class="d-flex pe-5 justify-content-end align-item-end w-100">
                        <button class="btn btn-primary removeAllCart">Remove All To Cart</button>
                    </div>
                </div>
                <div class="row">
                    <?php echo $showProduct ?>
                </div>
            </div>
        </div>
        <?php echo '<p class="d-none" id="userId">' . $userId . '</p>' ?>
        <div class="mt-4">
            <div class="border-top border-4 p-2 mb-3 d-flex justify-content-center  border-white">
                <strong>@copyright ankitchauhan0891@gmail.com</strong>
            </div>
        </div>
    </div>
    <script src="ajax/cart.js"></script>
    <script>

    </script>
    <?php include "../../footer.php"; ?>