<?php

$product = [
    "6274b35c6d17f" => [
        "title" => "Mens Cotton Jacket",
        "price" => 1200,
        'discount' => 0, 
        "description" => "great outerwear jackets for Spring/Autumn/Winter, suitable for many occasions, such as working, hiking, camping, mountain/rock climbing, cycling, traveling or other outdoors. Good gift choice for you or your family member. A warm hearted love to Father, husband or son in this thanksgiving or Christmas Day.",
        "category" => "Men's clothing",
        "image" => "https://fakestoreapi.com/img/71li-ujtlUL._AC_UX679_.jpg",
        "rating" => ["rate" => 4.7, "count" => 500],
        "created_time" => "01-01-2022 02:12:36 pm",
        "quantity" => 5
    ],
    "6274b35c6d1c0" => [
        "title" => "Mens Casual Slim Fit",
        "price" => 849,
        'discount' => 5, 
        "description" => "The color could be slightly different between on the screen and in practice. / Please note that body builds vary by person, therefore, detailed size information should be reviewed below on the product description.",
        "category" => "Men's clothing",
        "image" => "https://fakestoreapi.com/img/71YXzeOuslL._AC_UY879_.jpg",
        "rating" => ["rate" => 2.1, "count" => 430],
        "created_time" => "21-01-2022 06:01:12 am",
        "quantity" => 0
    ],
    "6274b35c6d1fe" => [
        "title" => "Solid Gold Petite Micropave ",
        "price" => 499,
        'discount' => 9, 
        "description" => "Satisfaction Guaranteed. Return or exchange any order within 30 days.Designed and sold by Hafeez Center in the United States. Satisfaction Guaranteed. Return or exchange any order within 30 days.",
        "category" => "Jewelry",
        "image" => "https://fakestoreapi.com/img/61sbMiUnoGL._AC_UL640_QL65_ML3_.jpg",
        "rating" => ["rate" => 3.9, "count" => 70],
        "created_time" => "12-02-2022 10:37:36 am",
        "quantity" => 7
    ],
    "6274b35c6d238" => [
        "id" => 7,
        "title" => "White Gold Plated Princess",
        "price" => 279,
        'discount' => 18, 
        "description" => "Classic Created Wedding Engagement Solitaire Diamond Promise Ring for Her. Gifts to spoil your love more for Engagement, Wedding, Anniversary, Valentine's Day...",
        "category" => "Jewelry",
        "image" => "https://fakestoreapi.com/img/71YAIFU48IL._AC_UL640_QL65_ML3_.jpg",
        "rating" => ["rate" => 3, "count" => 400],
        "created_time" => "24-02-2022 11:45:02 am",
        "quantity" => 7
    ],
    "6274b35c6d273" => [
        "title" => "WD 2TB Elements Portable External Hard Drive - USB 3.0 ",
        "price" => 5400,
        'discount' => 12, 
        "description" => "USB 3.0 and USB 2.0 Compatibility Fast data transfers Improve PC Performance High Capacity; Compatibility Formatted NTFS for Windows 10, Windows 8.1, Windows 7; Reformatting may be required for other operating systems; Compatibility may vary depending on user’s hardware configuration and operating system",
        "category" => "Electronics",
        "image" => "https://fakestoreapi.com/img/61IBBVJvSDL._AC_SY879_.jpg",
        "rating" => ["rate" => 3.3, "count" => 203],
        "created_time" => "15-03-2022 01:22:36 pm",
        "quantity" => 2
    ],
    "6274b35c6d2ad" => [
        "title" => "MBJ Women's Solid Short Sleeve Boat Neck V ",
        "price" => 349,
        'discount' => 3, 
        "description" => "95% RAYON 5% SPANDEX, Made in USA or Imported, Do Not Bleach, Lightweight fabric with great stretch for comfort, Ribbed on sleeves and neckline / Double stitching on bottom hem",
        "category" => "women's clothing",
        "image" => "https://fakestoreapi.com/img/71z3kpMAYsL._AC_UY879_.jpg",
        "rating" => ["rate" => 4.7, "count" => 130],
        "created_time" => "04-04-2022 9:30:36 am",
        "quantity" => 44
    ],
    "6274b35c6d2e7" => [
        "title" => "Rain Jacket Women Windbreaker Striped Climbing Raincoats",
        "price" => 1099,
        'discount' => 50, 
        "description" => "Lightweight perfet for trip or casual wear---Long sleeve with hooded, adjustable drawstring waist design. Button and zipper front closure raincoat, fully stripes Lined and The Raincoat has 2 side pockets are a good size to hold all kinds of things, it covers the hips, and the hood is generous but doesn't overdo it.Attached Cotton Lined Hood with Adjustable Drawstrings give it a real styled look.",
        "category" => "Women's clothing",
        "image" => "https://fakestoreapi.com/img/71HblAHs5xL._AC_UY879_-2.jpg",
        "rating" => ["rate" => 3.8, "count" => 679],
        "created_time" => "27-04-2022 04:04:04 pm",
        "quantity" => 50
    ],
    "6274b35c6d321" => [
        "title" => "Opna Women's Short Sleeve Moisture",
        "price" => 749,
        'discount' => 10, 
        "description" => "100% Polyester, Machine wash, 100% cationic polyester interlock, Machine Wash & Pre Shrunk for a Great Fit, Lightweight, roomy and highly breathable with moisture wicking fabric which helps to keep moisture away, Soft Lightweight Fabric with comfortable V-neck collar and a slimmer fit, delivers a sleek, more feminine silhouette and Added Comfort",
        "category" => "Women's clothing",
        "image" => "https://fakestoreapi.com/img/51eg55uWmdL._AC_UX679_.jpg",
        "rating" => ["rate" => 4.5, "count" => 146],
        "created_time" => "03-05-2022 10:37:36 pm",
        "quantity" => 33
    ]
];
