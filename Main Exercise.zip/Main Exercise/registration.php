<?php
session_start();
if (isset($_POST['submit'])) {

    $valid = true;
    $validForRegistration = true;

    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $password = trim($_POST['password']);

    if (empty($name)) {
        $errName = "Please enter name";
        $valid = false;
    } else if (strlen($name) < 2) {
        $errName = "Name should be at least 2 character long";
        $valid = false;
    } else if (!preg_match("/^[A-z]+( [A-z]*)*?$/", $name)) {
        $errName = "Name content alphabets only.";
        $valid = false;
    }


    if (empty($email)) {
        $errEmail = "Please enter email address";
        $valid = false;
    } else if (!preg_match("/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/", $email)) {
        $errEmail = "Please enter valid email address.";
        $valid = false;
    }

    if (empty($phone)) {
        $errPhone = "Please enter phone number";
        $valid = false;
    } else if (!preg_match("/^[0-9]{10}$/", $phone)) {
        $errPhone = "Please enter valid phone number.";
        $valid = false;
    }

    if ($password == "") {
        $errPassword = "Password is Required";
        $valid = false;
    } else if (!preg_match("/(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[$@!*#%&]).{8,}/", $password)) {
        $errPassword = "Password field Must Contain Uppercase letter, Lowercase letter, Number, And Special Characters and must be 8 charecters long";
        $valid = false;
    }

    if ($valid) {

        $filePath = $_SERVER['DOCUMENT_ROOT'] . '/assets/json/shoppingWebsite.json'; //path change

        if (!file_exists($filePath)) {
            $creatFile = fopen($filePath, 'w+');
            fwrite($creatFile,"[]");
            fclose($creatFile);
        }

        $getJsonData = file_get_contents($filePath);
        $tempArray = json_decode($getJsonData, true);

        foreach ($tempArray as $val) {
            $val = array_values($val['userDetails']);
            if (in_array($email, $val)) {
                $validForRegistration =  false;
                $errMessage = "This '$email' is already in use. </br> Please use other email id.";
            }
        }

        if ($validForRegistration) {

            //echo "<pre>"; print_r($arr); echo "</pre>"; exit; 
            $tempArray[uniqid()] = ['userDetails'=>["name" => $name, "email" => $email, "phone" => $phone, "password" => $password],'cart'=>[],'order'=>[]];
 
            $jsonData = json_encode($tempArray, JSON_PRETTY_PRINT);
            file_put_contents($filePath, $jsonData);
            //echo "<pre>"; print_r($tempArray); echo "</pre>";exit;

            $_SESSION['message'] = "User registration successful.";
            header("Location: login.php");
        }
    }
}



?>
<?php include '../../header.php'; ?>
<?php include '../sidebar.php' ?>
<aside aria-label="" class="column_right" style="overflow-x: hidden !important">
    <h1 class="path">PHP / Overview / Registration</h1>
    <div class="right_content bg-dark text-white d-flex align-items-center">
        <form class="w-50 mx-auto border border-4 p-4 m-4" name="myForm" method="post" action="" style="border-radius: 13px;" enctype="multipart/form-data">
            <h2 class="text-center my-4" style="font-weight: bold;">Registration</h2>

            <div class="mb-3">
                <label for="name" class="form-label">Name</label>
                <input type="text" name="name" placeholder="Please enter name" class="form-control" onkeyup="PHP_formURL_name()" value="<?php if (isset($_POST['name'])) {
                                                                                                                                            echo $_POST['name'];
                                                                                                                                        } ?>" autocomplete="off" id="name">
                <small class="text-danger" id="err_name"><?php if (isset($errName)) {
                                                                echo $errName;
                                                            } ?></small>
            </div>


            <div class="mb-3">
                <label for="email" class="form-label">Email Address</label>
                <input type="text" class="form-control" name="email" id="email" autocomplete="off" onkeyup="PHP_formURL_email()" placeholder="Please enter email address" value="<?php if (isset($_POST['email'])) {
                                                                                                                                                                                        echo $_POST['email'];
                                                                                                                                                                                    } ?>" onkeyup="PHP_Overview_email()">
                <small class="text-danger" id="err_email"><?php if (isset($errEmail)) {
                                                                echo $errEmail;
                                                            } ?></small>
            </div>

            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">Password</label>
                <input type="password" class="form-control" name="password" id="password" value="<?php if (isset($_POST['password'])) {
                                                                                                        echo $_POST['password'];
                                                                                                    } ?>" autocomplete="off" placeholder="Please enter password" onkeyup="PHP_Overview_password()">
                <small class="text-danger" id="err_password"><?php if (isset($errPassword)) {
                                                                    echo $errPassword;
                                                                } ?></small>
            </div>

            <div class="mb-3">
                <label for="phone" class="form-label">Phone Number</label>
                <input type="number" class="form-control" name="phone" id="phone" autocomplete="off" onkeyup="PHP_formURL_phone()" placeholder="Please enter phone number" value="<?php if (isset($_POST['phone'])) {
                                                                                                                                                                                        echo $_POST['phone'];
                                                                                                                                                                                    } ?>" onkeyup="PHP_Overview_phone()">
                <small class="text-danger" id="err_phone"><?php if (isset($errPhone)) {
                                                                echo $errPhone;
                                                            } ?></small>
            </div>

            <div class="d-flex justify-content-center mb-4">
                <input type="submit" value="Submit" name="submit" onclick="return PHP_formURL_StoreData_Sub()" class="btn btn-primary px-5 me-5">
            </div>
            <small class="text-danger" id="errMessage"><?php if (isset($errMessage)) {
                                                                echo $errMessage;
                                                            } ?></small>
        </form>
    </div>
    <?php include '../../footer.php'; ?>