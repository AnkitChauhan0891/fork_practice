<?php

if (isset($_POST['action'])) {
    if ($_POST['action'] == 'insertCart') {
        
        $user_id = $_POST['user_id'];
        $product_id = $_POST['product_id'];
        $quantity = $_POST['quantity'];

        $filePath = $_SERVER['DOCUMENT_ROOT'] . '/assets/json/shoppingWebsite.json';
        $getJsonData = file_get_contents($filePath);
        $tempArray = json_decode($getJsonData, true);
        $tempArray[$user_id]['cart'][$product_id] = ['quantity'=>$quantity];
        $jsonData = json_encode($tempArray, JSON_PRETTY_PRINT);
        file_put_contents($filePath, $jsonData);
        echo "add".$jsonData;
        exit;
    }
    if ($_POST['action'] == 'deleteCart') {
        
        $user_id = $_POST['user_id'];
        $product_id = $_POST['product_id'];

        $filePath = $_SERVER['DOCUMENT_ROOT'] . '/assets/json/shoppingWebsite.json';
        $getJsonData = file_get_contents($filePath);
        $tempArray = json_decode($getJsonData, true);

        unset($tempArray[$user_id]['cart'][$product_id]);
        $jsonData = json_encode($tempArray, JSON_PRETTY_PRINT);
        file_put_contents($filePath, $jsonData);
        echo "delete".$jsonData;
        exit;
    }
    if ($_POST['action'] == 'changeQuantity') {
        
        $user_id = $_POST['user_id'];
        $product_id = $_POST['product_id'];
        $quantity = $_POST['quantity'];

        $filePath = $_SERVER['DOCUMENT_ROOT'] . '/assets/json/shoppingWebsite.json';
        $getJsonData = file_get_contents($filePath);
        $tempArray = json_decode($getJsonData, true);
        $tempArray[$user_id]['cart'][$product_id]['quantity'] = $quantity;
        $jsonData = json_encode($tempArray, JSON_PRETTY_PRINT);
        file_put_contents($filePath, $jsonData);
        echo "add".$jsonData;
        exit;
    }

    if ($_POST['action'] == 'addAllProductCart') {
        
        $user_id = $_POST['user_id'];
        $cartProducts = $_POST['cartProducts'];

        

        $filePath = $_SERVER['DOCUMENT_ROOT'] . '/assets/json/shoppingWebsite.json';
        $getJsonData = file_get_contents($filePath);
        $tempArray = json_decode($getJsonData, true);
        $tempArray[$user_id]['cart'] = [];
        foreach($cartProducts as $val){
            $product_id = $val[0];
            $quantity = $val[1];
            $tempArray[$user_id]['cart'][$product_id]['quantity'] = $quantity;
        }
        $jsonData = json_encode($tempArray, JSON_PRETTY_PRINT);
        file_put_contents($filePath, $jsonData);
        
    }

    if ($_POST['action'] == 'removeAllProductCart') {
        
        $user_id = $_POST['user_id'];

        $filePath = $_SERVER['DOCUMENT_ROOT'] . '/assets/json/shoppingWebsite.json';
        $getJsonData = file_get_contents($filePath);
        $tempArray = json_decode($getJsonData, true);
        $tempArray[$user_id]['cart'] = [];
        $jsonData = json_encode($tempArray, JSON_PRETTY_PRINT);
        file_put_contents($filePath, $jsonData);
        
    }
}
