$(document).ready(function () {
  $(".addCart").click(function () {
    var user_id = $("#userId").text();
    var product_id = $(this).parents(".product").attr("id");
    var quantity = $(this).parent().parent().find("#quantity").val();

    var isChecked = $(this).children().attr("class");
    isChecked = isChecked.split(" ");
    console.log(isChecked);
    if (!isChecked.includes("cartToggle")) {
      $.ajax({
        type: "POST",
        url: "ajax/ajax.php",
        data: {
          user_id: user_id,
          product_id: product_id,
          quantity: quantity,
          action: "insertCart",
        },
        success: function (response) {
          //console.log(response);
        },
      });
    } else {
      $.ajax({
        type: "POST",
        url: "ajax/ajax.php",
        data: {
          user_id: user_id,
          product_id: product_id,
          action: "deleteCart",
        },
        success: function (response) {
          //console.log(response);
        },
      });
    }

    $(this).children().toggleClass("cartToggle");
  });

  $(".quantity-right-plus").click(function () {
    var user_id = $("#userId").text();
    var product_id = $(this).parents(".product").attr("id");

    var isChecked = $(this)
      .parents(".changeCart")
      .find(".addCart")
      .children()
      .attr("class");
    isChecked = isChecked.split(" ");

    var obj = $(this).parent().parent().find("input");
    var quantity = parseInt(obj.val());
    var total_quantity = parseInt(obj.attr("max"));
    if (quantity < total_quantity) {
      quantity = quantity + 1;
      obj.val(quantity);
    }

    if (isChecked.includes("cartToggle")) {
      $.ajax({
        type: "POST",
        url: "ajax/ajax.php",
        data: {
          user_id: user_id,
          product_id: product_id,
          quantity: quantity,
          action: "changeQuantity",
        },
        success: function (response) {
          //console.log(response);
        },
      });
    }
  });

  $(".quantity-left-minus").click(function () {
    var user_id = $("#userId").text();
    var product_id = $(this).parents(".product").attr("id");

    var isChecked = $(this)
      .parents(".changeCart")
      .find(".addCart")
      .children()
      .attr("class");
    isChecked = isChecked.split(" ");

    var obj = $(this).parent().parent().find("input");

    var quantity = parseInt(obj.val());

    if (quantity > 1) {
      quantity = quantity - 1;
      obj.val(quantity);
    }

    if (isChecked.includes("cartToggle")) {
      $.ajax({
        type: "POST",
        url: "ajax/ajax.php",
        data: {
          user_id: user_id,
          product_id: product_id,
          quantity: quantity,
          action: "changeQuantity",
        },
        success: function (response) {
          //console.log(response);
        },
      });
    }
  });

  $(".addAllCart").click(function () {
    var user_id = $("#userId").text();

    var arr = new Array();
    $(".product").each(function (key, val) {
      var product_id = $(this).attr("id");
      var quantity = $(this).find("#quantity").val();

      if (quantity > 0) {
        var tmpArray = [product_id,quantity]
        arr.push(tmpArray);
        $(this).find('.addCart').children().addClass("cartToggle");
      }
    });

    $.ajax({
      type: "POST",
      url: "ajax/ajax.php",
      data: {
        user_id: user_id,
        cartProducts: arr,
        action: "addAllProductCart",
      },
      success: function (response) {
        //console.log(response);
      },
    });
  });

  $(".removeAllCart").click(function () {
    var user_id = $("#userId").text();

    $.ajax({
      type: "POST",
      url: "ajax/ajax.php",
      data: {
        user_id: user_id,
        action: "removeAllProductCart",
      },
      success: function (response) {
        //console.log(response);
      },
    });
    $(".product").remove();
  });


});
