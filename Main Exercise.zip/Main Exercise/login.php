<?php
session_start();
if (isset($_POST['submit'])) {
    
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    $rememberMe = trim($_POST['rememberMe']);

    $validUser = true;
    $valid = true;

    if (empty($email)) {
        $errEmail = "";
        $valid = false;
    }
    if (empty($password)) {
        $errPassword = "";
        $valid = false;
    }

    if ($valid) {
        $filePath = $_SERVER['DOCUMENT_ROOT'] . '/assets/json/shoppingWebsite.json';
        if (file_exists($filePath)) {
            $inp = file_get_contents($filePath);
            $tempArray = json_decode($inp, true);
            foreach ($tempArray as $key=>$val) {
                $val = array_values($val['userDetails']);
                echo '<pre>'; print_r($val); '</pre>'; 
                
                if (!in_array($email, $val) && !in_array($password, $val)) {
                    $validUser =  false;
                    $errMessage = "Invalid User";
                }
                else{
                    $userId = $key;
                    $validUser =  true;
                }
            }
        }
    }
    if ($validUser) {
        if($rememberMe == "rememberMe")
        {
            setcookie('emailShopping', $email);
            setcookie('passwordShopping', $password);
            setcookie('rememberMeShopping', $rememberMe);
        }
        else{
            setcookie('email', "",time()-1);
            setcookie('password', "",time()-1);
            setcookie('rememberMeShopping', "",time()-1);
        }
        $_SESSION['user_id'] = $userId;
        header("Location: index.php");
    }
}

?>

<?php include '../../header.php'; ?>
<?php include '../sidebar.php' ?>

<aside aria-label="" class="column_right" style="overflow-x: hidden !important">
    <h1 class="path">PHP / Overview / Login</h1>
    <div class="right_content bg-dark text-white">
        <ol type="1" start="4">
            <li>Create an application for implement a "Remember Me" check-box to the login form, where the user's login info is remembered and reused when the user comes back later.</li>
        </ol>
        <form class="w-50 mx-auto border  border-4 p-4" method="post" action="" style="border-radius: 13px;">
            <h2 class="text-center my-4" style="font-weight: bold;">Login</h2>
            <div class="mb-3">
                <label for="email" class="form-label">Email ID</label>
                <input type="text" class="form-control" name="email" id="email" autocomplete="off" onkeyup="PHP_formURL_email()" placeholder="Please enter email address" value="<?php if (isset($_COOKIE['emailShopping']) && isset($_COOKIE['rememberMeShopping'])) {
                                                                                                                                                                                        echo $_COOKIE['emailShopping'];
                                                                                                                                                                                    } else {
                                                                                                                                                                                        echo '';
                                                                                                                                                                                    } ?>">
                <small class="text-danger" id="err_email"><?php if (isset($errEmail)) {
                                                                echo $errEmail;
                                                            } ?></small>
            </div>
            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">Password</label>
                <input type="password" class="form-control" name="password" id="password" autocomplete="off" placeholder="Please enter password" value="<?php if (isset($_COOKIE['passwordShopping']) && isset($_COOKIE['rememberMeShopping'])) {
                                                                                                                                                            echo $_COOKIE['passwordShopping'];
                                                                                                                                                        } else {
                                                                                                                                                            echo '';
                                                                                                                                                        } ?>" onkeyup="PHP_Overview_password()">
                <small class="text-danger" id="err_password"></small>
            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="checkbox" <?php if (isset($_COOKIE['rememberMeShopping']) && $_COOKIE['rememberMeShopping'] == 'rememberMe') {
                                                                    echo 'checked';
                                                                } ?> id="rememberMe" name="rememberMe" value="rememberMe">
                <label class="form-check-label" for="rememberMe">Remember Me</label>
            </div>
            <div class="d-flex justify-content-center mt-5 mb-4">
                <input type="submit" name="submit" value="Login " class="btn btn-primary px-5" id="login" onclick="return PHP_SessionCookie_log_sub()">
            </div>
            <div class="">
                <small class="fw-bold text-danger"><?php if (isset($errMessage)) {
                                                        echo $errMessage;
                                                    } ?></small>
            </div>
            <div class="">
                <small class="fw-bold text-success"><?php if (isset($_SESSION['message'])) {
                                                        echo $_SESSION['message'];
                                                        unset($_SESSION['message']);
                                                    } ?></small>
            </div>
            <div class="">
                <small class="text-muted fw-bold">Don't Have Account? <a href="registration.php" class="text-decoration-none text-primary">Register</a> </small>
            </div>
        </form>
    </div>

    <?php include '../../footer.php'; ?>